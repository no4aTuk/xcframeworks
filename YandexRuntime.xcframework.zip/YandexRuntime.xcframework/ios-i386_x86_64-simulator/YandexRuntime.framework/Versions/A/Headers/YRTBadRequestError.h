#import <YandexRuntime/YRTRemoteError.h>

/**
 * Client request is invalid (server returned the 400 'Bad Request'
 * response).
 */
@interface YRTBadRequestError : YRTRemoteError

@end

