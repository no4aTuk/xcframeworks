#import <YandexRuntime/YRTDiskCorruptError.h>

/**
 * The application does not have the required write permissions.
 */
@interface YRTDiskWriteAccessError : YRTDiskCorruptError

@end

