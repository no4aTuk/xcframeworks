#import <Foundation/Foundation.h>

@interface YRTCollection : NSObject

- (id)getItemOfClass:(Class)cls;

@end
