#import <YandexRuntime/YRTRemoteError.h>

/**
 * You do not have a valid MapKit API key.
 */
@interface YRTUnauthorizedError : YRTRemoteError

@end

