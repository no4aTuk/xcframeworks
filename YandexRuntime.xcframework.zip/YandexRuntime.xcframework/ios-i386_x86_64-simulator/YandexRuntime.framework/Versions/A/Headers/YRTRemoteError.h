#import <YandexRuntime/YRTError.h>

/**
 * Server responded in unexpected way: unparsable content, wrong content
 * or unexpected HTTP code.
 */
@interface YRTRemoteError : YRTError

@end

