#import <YandexRuntime/YRTViewProvider.h>

@interface YRTViewProvider ()

@property (nonatomic, readonly) UIImage* image;

@end
