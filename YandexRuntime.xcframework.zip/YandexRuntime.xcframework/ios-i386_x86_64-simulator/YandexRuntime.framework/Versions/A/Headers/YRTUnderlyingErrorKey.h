#import <Foundation/Foundation.h>

extern const NSString* YRTUnderlyingErrorKey;
