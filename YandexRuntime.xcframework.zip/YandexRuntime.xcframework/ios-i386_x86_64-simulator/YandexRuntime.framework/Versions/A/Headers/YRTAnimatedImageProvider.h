#import <Foundation/Foundation.h>

@protocol YRTAnimatedImageProvider

- (NSString*)imageId;
- (id)data;

@end
