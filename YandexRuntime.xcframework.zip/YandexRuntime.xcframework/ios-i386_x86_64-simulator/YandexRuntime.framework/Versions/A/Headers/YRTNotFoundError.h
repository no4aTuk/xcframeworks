#import <YandexRuntime/YRTRemoteError.h>

/**
 * Requested object has not been found. Most likely, your link is
 * outdated or the object has been deleted.
 */
@interface YRTNotFoundError : YRTRemoteError

@end

