#import <YandexMapKitSearch/YMKSearchDataTypes.h>
#import <YandexMapKitSearch/YMKSearchExperimentalMetadata.h>

#import <YandexMapKit/YMKPoint.h>

/**
 * Struct to fine-tune search request.
 */
@interface YMKSearchOptions : NSObject

/**
 * The search type can be one of YMKSearchType values or their bitwise
 * 'OR' combination. If searchType is not initialized, it means to
 * search in all the sources.
 */
@property (nonatomic, assign) YMKSearchType searchTypes;

/**
 * Maximum number of search results per page.
 *
 * Optional property, can be null.
 */
@property (nonatomic, copy) NSNumber *resultPageSize;

/**
 * Snippets that will be requested. The value should be one of
 * YMKSearchSnippet, or their bitwise 'OR' combination.
 */
@property (nonatomic, assign) YMKSearchSnippet snippets;

/**
 * Experimental snippets that will be requested. Requested snippets can
 * be found in YMKSearchExperimentalMetadata.
 */
@property (nonatomic, strong) NSArray<NSString *> *experimentalSnippets;

/**
 * The server uses the user position to calculate the distance from the
 * user to search results.
 *
 * Optional property, can be null.
 */
@property (nonatomic, strong) YMKPoint *userPosition;

/**
 * String that sets an identifier for the request source.
 *
 * Optional property, can be null.
 */
@property (nonatomic, copy) NSString *origin;

/**
 * The landing page ID for Yandex.Direct. If set, the banners may be
 * present in the search response.
 *
 * Optional property, can be null.
 */
@property (nonatomic, copy) NSString *directPageId;

/**
 * The context from an Apple-directed session.
 *
 * Optional property, can be null.
 */
@property (nonatomic, copy) NSString *appleCtx;

/**
 * Adds the geometry to the server response.
 */
@property (nonatomic, assign) BOOL geometry;

/**
 * The landing page ID for ads.
 *
 * Optional property, can be null.
 */
@property (nonatomic, copy) NSString *advertPageId;

/**
 * Enable word-by-word suggestion items.
 */
@property (nonatomic, assign) BOOL suggestWords;

/**
 * Force disable misspell correction.
 */
@property (nonatomic, assign) BOOL disableSpellingCorrection;

+ (nonnull YMKSearchOptions *)searchOptionsWithSearchTypes:( YMKSearchType)searchTypes
                                            resultPageSize:(nullable NSNumber *)resultPageSize
                                                  snippets:( YMKSearchSnippet)snippets
                                      experimentalSnippets:(nonnull NSArray<NSString *> *)experimentalSnippets
                                              userPosition:(nullable YMKPoint *)userPosition
                                                    origin:(nullable NSString *)origin
                                              directPageId:(nullable NSString *)directPageId
                                                  appleCtx:(nullable NSString *)appleCtx
                                                  geometry:( BOOL)geometry
                                              advertPageId:(nullable NSString *)advertPageId
                                              suggestWords:( BOOL)suggestWords
                                 disableSpellingCorrection:( BOOL)disableSpellingCorrection;


@end
