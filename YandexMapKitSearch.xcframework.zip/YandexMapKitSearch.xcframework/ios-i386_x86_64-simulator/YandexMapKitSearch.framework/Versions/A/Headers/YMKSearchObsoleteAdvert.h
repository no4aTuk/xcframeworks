#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Contains information about the advertisement.
 */
@interface YMKSearchObsoleteAdvert : NSObject

/**
 * Title.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *title;

/**
 * Text.
 */
@property (nonatomic, readonly, nonnull) NSString *text;

/**
 * Disclaimers.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *disclaimers;

/**
 * Optional link.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *url;

/**
 * Optional phone for the advert.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *phone;

/**
 * Optional style that can be used to create an icon for the
 * advertisement.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *style;

/**
 * Human-readable identifier for logging.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *logId;

/**
 * Additional string-based info.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *tags;


+ (nonnull YMKSearchObsoleteAdvert *)obsoleteAdvertWithTitle:(nullable NSString *)title
                                                        text:(nonnull NSString *)text
                                                 disclaimers:(nonnull NSArray<NSString *> *)disclaimers
                                                         url:(nullable NSString *)url
                                                       phone:(nullable NSString *)phone
                                                       style:(nullable NSString *)style
                                                       logId:(nullable NSString *)logId
                                                        tags:(nonnull NSArray<NSString *> *)tags;


@end
/// @endcond

