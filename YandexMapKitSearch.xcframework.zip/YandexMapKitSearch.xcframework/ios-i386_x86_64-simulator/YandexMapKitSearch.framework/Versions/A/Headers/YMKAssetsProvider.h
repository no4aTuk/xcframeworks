#import <YandexMapKitSearch/YMKSize.h>

#import <UIKit/UIKit.h>
#import <YandexMapKit/YMKIconStyle.h>

@class YMKSearchResultItem;

/**
 * Possible placemark icon types
 */
typedef NS_ENUM(NSUInteger, YMKPlacemarkIconType) {

    /**
     * No icon
     */
    YMKPlacemarkIconTypeNone,

    /**
     * Dust
     */
    YMKPlacemarkIconTypeDust,

    /**
     * Dust, search result is already visited
     */
    YMKPlacemarkIconTypeDustVisited,

    /**
     * Icon
     */
    YMKPlacemarkIconTypeIcon,

    /**
     * Icon, search result is already visited
     */
    YMKPlacemarkIconTypeIconVisited,

    /**
     * One-line label to the left of the icon
     */
    YMKPlacemarkIconTypeLabelShortLeft,

    /**
     * One-line label to the right of the icon
     */
    YMKPlacemarkIconTypeLabelShortRight,

    /**
     * Detailed label to the left of the icon
     */
    YMKPlacemarkIconTypeLabelDetailedLeft,

    /**
     * Detailed label to the right of the icon
     */
    YMKPlacemarkIconTypeLabelDetailedRight,

    /**
     * Search result is selected
     */
    YMKPlacemarkIconTypeSelected
};


/**
 * Interface for providing images, image sizes and icon styles to the
 * search layer. Call with static_cast<int>(PlacemarkIconType) in all
 * methods.
 */
@protocol YMKAssetsProvider <NSObject>

/**
 * Returns an image for certain placemark type with given search result
 */
- (nonnull UIImage *)imageWithSearchResult:(nonnull YMKSearchResultItem *)searchResult
                         placemarkIconType:(NSInteger)placemarkIconType;


/**
 * Returns the size of the icon of certain placemark type with given
 * search result
 */
- (nonnull YMKSize *)sizeWithSearchResult:(nonnull YMKSearchResultItem *)searchResult
                        placemarkIconType:(NSInteger)placemarkIconType;


/**
 * Returns the icon style for certain placemark type with given search
 * result. If obtainAdIcons mode is enabled, IconStyle.anchor will be
 * replaced for advertisement pins
 */
- (nonnull YMKIconStyle *)iconStyleWithSearchResult:(nonnull YMKSearchResultItem *)searchResult
                                  placemarkIconType:(NSInteger)placemarkIconType;


@end
