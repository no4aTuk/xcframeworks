#import <YandexMapKitSearch/YMKSearchBusinessListObjectMetadata.h>
#import <YandexMapKitSearch/YMKSearchBusinessPhotoObjectMetadata.h>
#import <YandexMapKitSearch/YMKSearchBusinessRating1xObjectMetadata.h>
#import <YandexMapKitSearch/YMKSearchBusinessRating2xObjectMetadata.h>
#import <YandexMapKitSearch/YMKSearchCurrencyExchangeMetadata.h>
#import <YandexMapKitSearch/YMKSearchFuelMetadata.h>
#import <YandexMapKitSearch/YMKSearchMassTransit1xObjectMetadata.h>
#import <YandexMapKitSearch/YMKSearchPanoramasObjectMetadata.h>
#import <YandexMapKitSearch/YMKSearchRelatedPlacesObjectMetadata.h>
#import <YandexMapKitSearch/YMKSearchRouteDistancesObjectMetadata.h>
#import <YandexMapKitSearch/YMKSearchRoutePointMetadata.h>
#import <YandexMapKitSearch/YMKSearchRouterObjectMetadata.h>
#import <YandexMapKitSearch/YMKSearchShowtimesObjectMetadata.h>
#import <YandexMapKitSearch/YMKSearchSubtitleMetadata.h>

/**
 * Precision for matching house numbers (response vs. request).
 */
typedef NS_ENUM(NSUInteger, YMKSearchPrecision) {

    /**
     * The house number in the response is exactly the same as requested
     * (3/2 vs. 3/2)
     */
    YMKSearchPrecisionExact,

    /**
     * The house number in the response has the same number part as the
     * requested one (5 vs. 5a).
     */
    YMKSearchPrecisionNumber,

    /**
     * The house number and coordinates are restored from the house range.
     * This means that there is no information about this specific house,
     * but there is information about a range of houses to infer house
     * position from.
     */
    YMKSearchPrecisionRange,

    /**
     * The house number in the response is close to the requested one (13
     * vs. 11).
     */
    YMKSearchPrecisionNearby
};


/**
 * Bitmask for requested search types.
 */
typedef NS_OPTIONS(NSUInteger, YMKSearchType) {

    /// @cond EXCLUDE
    /**
     * Default value: all types requested.
     */
    YMKSearchTypeNone = 0,
    /// @endcond

    /**
     * Toponyms.
     */
    YMKSearchTypeGeo = 1,

    /**
     * Companies.
     */
    YMKSearchTypeBiz = 1 << 1,

    /**
     * Mass transit routes.
     */
    YMKSearchTypeTransit = 1 << 2,

    /**
     * Collections.
     */
    YMKSearchTypeCollections = 1 << 3,

    /// @cond EXCLUDE
    /**
     * Direct advertisements.
     */
    YMKSearchTypeDirect = 1 << 4,
    /// @endcond

    /// @cond EXCLUDE
    /**
     * Goods.
     */
    YMKSearchTypeGoods = 1 << 5,
    /// @endcond

    /// @cond EXCLUDE
    /**
     * Points of interest (POI).
     */
    YMKSearchTypePointsOfInterest = 1 << 6,
    /// @endcond

    /**
     * Masstransit.
     */
    YMKSearchTypeMassTransit = 1 << 7
};


/**
 * Requested snippets bitmask.
 *
 * Snippets are additional pieces of information (possibly from
 * different services) which are not directly stored in object metadata
 * but may be requested separately based on client needs.
 *
 * Different snippets are applicable to different objects: some of the
 * snippets can be provided only for toponyms, some for businesses and
 * some for all object types.
 */
typedef NS_OPTIONS(NSUInteger, YMKSearchSnippet) {

    /**
     * Default value: no snippets requested.
     */
    YMKSearchSnippetNone = 0,

    /// @cond EXCLUDE
    /**
     * Related photos snippet (can be requested for a business or toponym).
     * See YMKSearchBusinessPhotoObjectMetadata.
     */
    YMKSearchSnippetPhotos = 1,
    /// @endcond

    /// @cond EXCLUDE
    /**
     * Information about ratings (can be requested for a business). See
     * YMKSearchBusinessRating1xObjectMetadata.
     */
    YMKSearchSnippetBusinessRating1x = 1 << 1,
    /// @endcond

    /**
     * Information about ratings (can be requested for a business). See
     * YMKSearchBusinessRating2xObjectMetadata.
     */
    YMKSearchSnippetBusinessRating2x = 1 << 2,

    /// @cond EXCLUDE
    /**
     * Businesses at this address (can be requested for a toponym). See
     * YMKSearchBusinessListObjectMetadata.
     */
    YMKSearchSnippetBusinessList = 1 << 3,
    /// @endcond

    /**
     * Available routing types for this point. See
     * YMKSearchRouterObjectMetadata.
     */
    YMKSearchSnippetRouter = 1 << 4,

    /// @cond EXCLUDE
    /**
     * Nearest panoramas to this point. See
     * YMKSearchPanoramasObjectMetadata.
     */
    YMKSearchSnippetPanoramas = 1 << 5,
    /// @endcond

    /**
     * Nearest mass transit stops to this point. See
     * YMKSearchMassTransit1xObjectMetadata.
     */
    YMKSearchSnippetMassTransit = 1 << 6,

    /// @cond EXCLUDE
    /**
     * Experimental snippets. Do not use.
     */
    YMKSearchSnippetExperimental = 1 << 7,
    /// @endcond

    /// @cond EXCLUDE
    /**
     * Route times and distances for different transport types for this
     * point. See YMKSearchRouteDistancesObjectMetadata.
     */
    YMKSearchSnippetRouteDistances = 1 << 8,
    /// @endcond

    /**
     * Related businesses (can be requested for a business). See
     * YMKSearchRelatedPlacesObjectMetadata.
     */
    YMKSearchSnippetRelatedPlaces = 1 << 9,

    /// @cond EXCLUDE
    /**
     * Related images (can be requested for a business).
     */
    YMKSearchSnippetBusinessImages = 1 << 10,
    /// @endcond

    /**
     * References to external IDs.
     */
    YMKSearchSnippetReferences = 1 << 11,

    /**
     * Fuel snippet. See YMKSearchFuelMetadata.
     */
    YMKSearchSnippetFuel = 1 << 12,

    /**
     * Currency exchange snippet. See YMKSearchCurrencyExchangeMetadata.
     */
    YMKSearchSnippetExchange = 1 << 13,

    /**
     * Nearest mass transit stops. Provides more detailed information about
     * mass transit lines compared to the Masstransit snippet.
     */
    YMKSearchSnippetNearbyStops = 1 << 14,

    /**
     * Subtitle snippet. See YMKSearchSubtitleMetadata.
     */
    YMKSearchSnippetSubtitle = 1 << 15,

    /**
     * RoutePoint snippet. See YMKSearchRoutePointMetadata.
     */
    YMKSearchSnippetRoutePoint = 1 << 16,

    /**
     * Showtimes snippet. See YMKSearchShowtimesObjectMetadata.
     */
    YMKSearchSnippetShowtimes = 1 << 17
};

