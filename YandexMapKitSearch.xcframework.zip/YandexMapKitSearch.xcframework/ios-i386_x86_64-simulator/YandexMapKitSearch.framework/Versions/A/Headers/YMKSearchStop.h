#import <YandexMapKitSearch/YMKSearchLine.h>

#import <YandexMapKit/YMKLocalizedValue.h>
#import <YandexMapKit/YMKPoint.h>

@class YMKSearchStopStyle;

/// @cond EXCLUDE
/**
 * Describes a mass transit stop.
 */
@interface YMKSearchStop : NSObject

/**
 * Mass transit stop name.
 */
@property (nonatomic, readonly, nonnull) NSString *name;

/**
 * Localized distance to the stop.
 */
@property (nonatomic, readonly, nonnull) YMKLocalizedValue *distance;

/**
 * Nearest stop style, such as color.
 */
@property (nonatomic, readonly, nonnull) YMKSearchStopStyle *style;

/**
 * Mass transit stop point.
 */
@property (nonatomic, readonly, nonnull) YMKPoint *point;

/**
 * Nearest stop ID.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *stopId;

/**
 * Line that the nearest stop is on.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchLine *line;


+ (nonnull YMKSearchStop *)stopWithName:(nonnull NSString *)name
                               distance:(nonnull YMKLocalizedValue *)distance
                                  style:(nonnull YMKSearchStopStyle *)style
                                  point:(nonnull YMKPoint *)point
                                 stopId:(nullable NSString *)stopId
                                   line:(nullable YMKSearchLine *)line;


@end
/// @endcond


/**
 * Mass transit stop style.
 */
@interface YMKSearchStopStyle : NSObject

/**
 * Mass transit stop color.
 */
@property (nonatomic, readonly) NSInteger color;


+ (nonnull YMKSearchStopStyle *)styleWithColor:( NSInteger)color;


@end

