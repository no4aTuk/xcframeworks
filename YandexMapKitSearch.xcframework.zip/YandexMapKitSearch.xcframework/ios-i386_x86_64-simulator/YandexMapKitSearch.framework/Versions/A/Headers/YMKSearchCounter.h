#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Counter for Yandex.Direct ads.
 */
@interface YMKSearchCounter : NSObject

/**
 * YABS counter type.
 */
@property (nonatomic, readonly, nonnull) NSString *type;

/**
 * Link to external site (via YABS).
 */
@property (nonatomic, readonly, nonnull) NSString *url;


+ (nonnull YMKSearchCounter *)counterWithType:(nonnull NSString *)type
                                          url:(nonnull NSString *)url;


@end
/// @endcond

