#import <YandexMapKitSearch/YMKSearchNearbyStop.h>

/// @cond EXCLUDE
/**
 * Snippet data to get nearby mass transit stops info.
 */
@interface YMKSearchMassTransit2xObjectMetadata : NSObject

/**
 * A list of nearby mass transit stops.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchNearbyStop *> *stops;


+ (nonnull YMKSearchMassTransit2xObjectMetadata *)massTransit2xObjectMetadataWithStops:(nonnull NSArray<YMKSearchNearbyStop *> *)stops;


@end
/// @endcond

