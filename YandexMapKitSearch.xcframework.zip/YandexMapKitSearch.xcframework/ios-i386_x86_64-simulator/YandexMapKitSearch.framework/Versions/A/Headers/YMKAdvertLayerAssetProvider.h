#import <UIKit/UIKit.h>

/// @cond EXCLUDE
/**
 * Label placement relatilve to an advert pin.
 */
typedef NS_ENUM(NSUInteger, YMKAdvertLayerLabelPlacement) {

    YMKAdvertLayerLabelPlacementLeft,

    YMKAdvertLayerLabelPlacementRight
};
/// @endcond


/// @cond EXCLUDE
/**
 * Interface for providing images to the advert layer.
 */
@protocol YMKAdvertLayerAssetProvider <NSObject>

/**
 * Returns an image of a label for an advert pin
 *
 * Remark:
 * @param imageId has optional type, it may be uninitialized.
 */
- (nullable UIImage *)advertLabelImageWithTitle:(nonnull NSString *)title
                                       subtitle:(nonnull NSString *)subtitle
                                        imageId:(nullable NSString *)imageId
                                      nightMode:(BOOL)nightMode
                                      placement:(YMKAdvertLayerLabelPlacement)placement;


@end
/// @endcond
