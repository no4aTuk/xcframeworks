#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Company contact info.
 */
@interface YMKSearchContactInfo : NSObject

/**
 * Company name.
 */
@property (nonatomic, readonly, nonnull) NSString *companyName;

/**
 * Company formatted address.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *address;

/**
 * Company phone.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *phone;

/**
 * Company email.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *email;

/**
 * Company working hours.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *hours;


+ (nonnull YMKSearchContactInfo *)contactInfoWithCompanyName:(nonnull NSString *)companyName
                                                     address:(nullable NSString *)address
                                                       phone:(nullable NSString *)phone
                                                       email:(nullable NSString *)email
                                                       hours:(nullable NSString *)hours;


@end
/// @endcond

