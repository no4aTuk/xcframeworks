#import <YandexMapKit/YMKTaxiMoney.h>
#import <YandexMapKit/YMKTime.h>

/**
 * Session details.
 */
@interface YMKSearchShowtime : NSObject

/**
 * Session start time.
 */
@property (nonatomic, readonly, nonnull) YMKTime *startTime;

/**
 * Ticket price.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKTaxiMoney *price;

/**
 * Ticket id.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *ticketId;


+ (nonnull YMKSearchShowtime *)showtimeWithStartTime:(nonnull YMKTime *)startTime
                                               price:(nullable YMKTaxiMoney *)price
                                            ticketId:(nullable NSString *)ticketId;


@end

