#import <YandexMapKitSearch/YMKSearchDrivingArrivalPoint.h>
#import <YandexMapKitSearch/YMKSearchEntrance.h>

/**
 * Route point info snippet
 */
@interface YMKSearchRoutePointMetadata : NSObject

/**
 * A string that a client can pass in router requests to get better
 * options of a destination point. The string encodes entrances, driving
 * arrival points and anything else that can be used as a destination
 * point to a particular toponym or organization. Format of that string
 * is internal and can be changed without any notice.
 */
@property (nonatomic, readonly, nonnull) NSString *routePointContext;

@property (nonatomic, readonly, nonnull) NSArray<YMKSearchEntrance *> *entrances;

@property (nonatomic, readonly, nonnull) NSArray<YMKSearchDrivingArrivalPoint *> *drivingArrivalPoints;


+ (nonnull YMKSearchRoutePointMetadata *)routePointMetadataWithRoutePointContext:(nonnull NSString *)routePointContext
                                                                       entrances:(nonnull NSArray<YMKSearchEntrance *> *)entrances
                                                            drivingArrivalPoints:(nonnull NSArray<YMKSearchDrivingArrivalPoint *> *)drivingArrivalPoints;


@end

