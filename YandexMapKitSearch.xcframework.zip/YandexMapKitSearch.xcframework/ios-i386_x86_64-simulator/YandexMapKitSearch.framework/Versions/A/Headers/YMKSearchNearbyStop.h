#import <YandexMapKit/YMKLocalizedValue.h>
#import <YandexMapKit/YMKPoint.h>

@class YMKSearchNearbyStopLine;
@class YMKSearchNearbyStopLineAtStop;
@class YMKSearchNearbyStopStop;
@class YMKSearchNearbyStopStyle;

/// @cond EXCLUDE
/**
 * Describes a nearby mass transit stop.
 */
@interface YMKSearchNearbyStop : NSObject

/**
 * Public transport stop.
 */
@property (nonatomic, readonly, nonnull) YMKSearchNearbyStopStop *stop;

/**
 * Nearby stop point.
 */
@property (nonatomic, readonly, nonnull) YMKPoint *point;

/**
 * Localized distance to the nearby stop.
 */
@property (nonatomic, readonly, nonnull) YMKLocalizedValue *distance;

/**
 * A list of public transport lines that go through this nearby stop.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchNearbyStopLineAtStop *> *linesAtStop;


+ (nonnull YMKSearchNearbyStop *)nearbyStopWithStop:(nonnull YMKSearchNearbyStopStop *)stop
                                              point:(nonnull YMKPoint *)point
                                           distance:(nonnull YMKLocalizedValue *)distance
                                        linesAtStop:(nonnull NSArray<YMKSearchNearbyStopLineAtStop *> *)linesAtStop;


@end
/// @endcond


/// @cond EXCLUDE
/**
 * Defines a visual style, such as color.
 */
@interface YMKSearchNearbyStopStyle : NSObject

/**
 * Element color in #RRGGBB format.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSNumber *color;


+ (nonnull YMKSearchNearbyStopStyle *)styleWithColor:(nullable NSNumber *)color;


@end
/// @endcond


/// @cond EXCLUDE
/**
 * Describes a public transport line.
 */
@interface YMKSearchNearbyStopLine : NSObject

/**
 * Line ID.
 */
@property (nonatomic, readonly, nonnull) NSString *id;

/**
 * Line name.
 */
@property (nonatomic, readonly, nonnull) NSString *name;

/**
 * Line style, such as color.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchNearbyStopStyle *style;

/**
 * Line vehicle types.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *vehicleTypes;


+ (nonnull YMKSearchNearbyStopLine *)lineWithId:(nonnull NSString *)id
                                           name:(nonnull NSString *)name
                                          style:(nullable YMKSearchNearbyStopStyle *)style
                                   vehicleTypes:(nonnull NSArray<NSString *> *)vehicleTypes;


@end
/// @endcond


/// @cond EXCLUDE
/**
 * Provides information about a public transport line that goes through
 * the specified mass transit stop.
 */
@interface YMKSearchNearbyStopLineAtStop : NSObject

/**
 * Public transport line.
 */
@property (nonatomic, readonly, nonnull) YMKSearchNearbyStopLine *line;


+ (nonnull YMKSearchNearbyStopLineAtStop *)lineAtStopWithLine:(nonnull YMKSearchNearbyStopLine *)line;


@end
/// @endcond


/// @cond EXCLUDE
/**
 * Identifies a public transport stop.
 */
@interface YMKSearchNearbyStopStop : NSObject

/**
 * Stop ID.
 */
@property (nonatomic, readonly, nonnull) NSString *id;

/**
 * Stop name.
 */
@property (nonatomic, readonly, nonnull) NSString *name;


+ (nonnull YMKSearchNearbyStopStop *)stopWithId:(nonnull NSString *)id
                                           name:(nonnull NSString *)name;


@end
/// @endcond

