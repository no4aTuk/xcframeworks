#import <YandexMapKitSearch/YMKSearchGoods.h>

@interface YMKSearchGoodsObjectMetadata : NSObject

/**
 * Goods list matching user query.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchGoods *> *goods;


+ (nonnull YMKSearchGoodsObjectMetadata *)goodsObjectMetadataWithGoods:(nonnull NSArray<YMKSearchGoods *> *)goods;


@end

