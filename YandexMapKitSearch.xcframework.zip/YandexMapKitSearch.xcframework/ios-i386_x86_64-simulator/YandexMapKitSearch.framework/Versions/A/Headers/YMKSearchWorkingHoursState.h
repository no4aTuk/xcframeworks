#import <Foundation/Foundation.h>

/**
 * Describes if an organization is open or closed now.
 */
@interface YMKSearchWorkingHoursState : NSObject

/**
 * Is open right now.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSNumber *isOpenNow;

/**
 * Human-readable localized description of current state. For example,
 * "Закроется в 20:00".
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *text;

/**
 * Human-readable short localized description of current state. For
 * example, "До 20:00".
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *shortText;

/**
 * One of the following 3 tags: 'break', 'opening_soon', 'closing_soon'.
 * Additional tag values may be added eventually.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *tags;


+ (nonnull YMKSearchWorkingHoursState *)workingHoursStateWithIsOpenNow:(nullable NSNumber *)isOpenNow
                                                                  text:(nullable NSString *)text
                                                             shortText:(nullable NSString *)shortText
                                                                  tags:(nonnull NSArray<NSString *> *)tags;


@end

