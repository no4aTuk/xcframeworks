#import <Foundation/Foundation.h>

/**
 * Interface for callbacks on search events.
 */
@protocol YMKSearchLayerResponseHandler <NSObject>

/**
 * Called when the search starts.
 */
- (void)onSearchStart;


/**
 * Called after a succesful search.
 */
- (void)onSearchSuccess;


/**
 * Called on any search error.
 *
 * @param error Error occured.
 */
- (void)onSearchErrorWithError:(nonnull NSError *)error;


/**
 * Called when presented results are updated and thus search results
 * list can change
 */
- (void)onPresentedResultsUpdate;


@end
