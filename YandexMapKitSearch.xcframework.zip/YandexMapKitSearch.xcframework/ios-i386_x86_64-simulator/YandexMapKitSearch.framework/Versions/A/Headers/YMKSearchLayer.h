#import <YandexMapKitSearch/YMKAssetsProvider.h>
#import <YandexMapKitSearch/YMKSearchBitmapDownloader.h>
#import <YandexMapKitSearch/YMKSearchBusinessFilter.h>
#import <YandexMapKitSearch/YMKSearchLayerResponseHandler.h>
#import <YandexMapKitSearch/YMKSearchLayerTapHandler.h>
#import <YandexMapKitSearch/YMKSearchManager.h>
#import <YandexMapKitSearch/YMKSearchMetadata.h>
#import <YandexMapKitSearch/YMKSearchOptions.h>

#import <YandexRuntime/YRTPlatformBinding.h>

#import <UIKit/UIKit.h>
#import <YandexMapKit/YMKGeometry.h>
#import <YandexMapKit/YMKIconStyle.h>

@class YMKSearchResultItem;

/**
 * Type of search with geometry.
 */
typedef NS_ENUM(NSUInteger, YMKGeometrySearchType) {

    /**
     * Search along the whole geometry.
     */
    YMKGeometrySearchTypeWhole,

    /**
     * Search along the geometry in the current window.
     */
    YMKGeometrySearchTypeCurrentWindow
};


/**
 * The search layer handles the map search requests and displays the
 * results automatically on the map. It also handles the map movements
 * and resubmits searches when needed.
 */
@interface YMKSearchLayer : YRTPlatformBinding

/**
 * Submit search query with search options.
 *
 * @param query User query.
 * @param searchOptions Search options.
 */
- (void)submitQueryWithQuery:(nonnull NSString *)query
               searchOptions:(nonnull YMKSearchOptions *)searchOptions;


/**
 * Submit search request for URI resolution.
 *
 * @param uri Object URI.
 * @param searchOptions Additional search parameters. See
 * YMKSearchOptions definition for details, and 'resolveURI' method in
 * YMKSearchManager for currently supported options.
 */
- (void)resolveUriWithUri:(nonnull NSString *)uri
            searchOptions:(nonnull YMKSearchOptions *)searchOptions;


/**
 * Submit search request by organization ID.
 *
 * @param oid ID of organization.
 * @param searchOptions Additional search parameters. See
 * YMKSearchOptions definition for details, and 'searchByOid' method in
 * YMKSearchManager for currently supported options.
 */
- (void)searchByOidWithOid:(nonnull NSString *)oid
             searchOptions:(nonnull YMKSearchOptions *)searchOptions;


/**
 * Manual resubmit.
 */
- (void)resubmit;


/**
 * Enable or disable search resubmits when the map is moved. Resubmits
 * are enabled by default.
 *
 * @param enable Enable resubmits if true, disable otherwise.
 */
- (void)enableResubmitsOnMapMovesWithEnable:(BOOL)enable;


/**
 * Enable or disable moving the map to the primary search response.
 * Moving the map is enabled by default.
 *
 * @param enable Enable map moving if true, disable otherwise.
 */
- (void)enableMapMoveOnSearchResponseWithEnable:(BOOL)enable;


/**
 * Check if more results could be loaded.
 */
- (BOOL)hasNextPage;


/**
 * Load the next page of results.
 */
- (void)fetchNextPage;


/**
 * Clear the displayed search results from the map.
 */
- (void)clear;


/**
 * Get the list of search results.
 */
- (nonnull NSArray<YMKSearchResultItem *> *)getSearchResultsList;


/**
 * Get the last search response metadata.
 */
- (nullable YMKSearchMetadata *)searchMetadata;


/**
 * Set search manager. Do not use this method; it is for internal use
 * only.
 *
 * @param searchManager Search manager.
 */
- (void)setSearchManagerWithSearchManager:(nonnull YMKSearchManager *)searchManager;


/**
 * Set bitmap downloader. Do not use this method; it is for internal use
 * only.
 *
 * @param bitmapDownloader Bitmap downloader.
 */
- (void)setBitmapDownloaderWithBitmapDownloader:(nonnull YMKSearchBitmapDownloader *)bitmapDownloader;


/**
 * Add the search result listener which will receive notifications from
 * the search layer.
 *
 * @param searchResultListener Search result listener to add.
 */
- (void)addSearchResultListenerWithSearchResultListener:(nonnull id<YMKSearchLayerResponseHandler>)searchResultListener;


/**
 * Remove search result listener.
 *
 * @param searchResultListener Search result listener to remove.
 */
- (void)removeSearchResultListenerWithSearchResultListener:(nonnull id<YMKSearchLayerResponseHandler>)searchResultListener;


/**
 * Add the placemark listener which will receive notifications from the
 * search layer.
 *
 * @param placemarkListener Placemark listener to add.
 */
- (void)addPlacemarkListenerWithPlacemarkListener:(nonnull id<YMKSearchLayerTapHandler>)placemarkListener;


/**
 * Remove placemark listener.
 *
 * @param placemarkListener Placemark listener to remove.
 */
- (void)removePlacemarkListenerWithPlacemarkListener:(nonnull id<YMKSearchLayerTapHandler>)placemarkListener;


/**
 * Set sort order of the results by search rank.
 */
- (void)setSortByRank;


/**
 * Set sort order of the results by the distance to the geometry.
 *
 * @param origin Geometry to sort by.
 * @param geometrySearchType Geometry search type.
 */
- (void)setSortByDistanceWithOrigin:(nonnull YMKGeometry *)origin
                 geometrySearchType:(YMKGeometrySearchType)geometrySearchType;


/**
 * Set search filters.
 *
 * @param filters Business filters.
 */
- (void)setFiltersWithFilters:(nonnull NSArray<YMKSearchBusinessFilter *> *)filters;


/**
 * Set the custom asset provider, which provides images, sizes and icon
 * styles for placemarks.
 *
 * @param provider Asset provider (must not be null).
 */
- (void)setAssetsProviderWithProvider:(nonnull id<YMKAssetsProvider>)provider;


/**
 * Reset the asset provider to default.
 */
- (void)resetAssetsProvider;


/**
 * Set the base z-index for displaying map objects from search results.
 * It is guaranteed that all map objects from search will have the
 * z-index within the interval [base; base + 10] Note: if the asset
 * provider explicitly sets the z-index for an icon, then it is not
 * guaranteed that the icon will have a z-index within the interval
 * [base; base + 10]
 */
- (void)setBaseZIndexWithZIndex:(float)zIndex;


/**
 * Select placemark by ID.
 *
 * @param geoObjectId Placemark identifier.
 */
- (void)selectPlacemarkWithGeoObjectId:(nonnull NSString *)geoObjectId;


/**
 * Selected placemark ID.
 *
 * @return s  Placemark identifier if any placemark is selected, nothing
 * otherwise.
 */
- (nullable NSString *)selectedPlacemarkId;


/**
 * Deselect all placemarks.
 */
- (void)deselectPlacemark;


/**
 * Update the icon image for each suitable placemark. If the placemark
 * is not found, the image will be put in a queue and will be applied
 * once when the placemark is created. This is not the regular way to
 * set the image. It is highly advisable to return the correct image
 * from AssetsProvider.
 *
 * @param geoObjectId Placemark identifier.
 * @param iconType Icon type.
 * @param image Icon image.
 * @param style Icon style.
 */
- (void)forceUpdateIconWithGeoObjectId:(nonnull NSString *)geoObjectId
                              iconType:(YMKPlacemarkIconType)iconType
                                 image:(nonnull UIImage *)image
                                 style:(nonnull YMKIconStyle *)style;


/**
 * Force reloading of all visible pins from AssetsProvider. Use when it
 * is necessary to update ALL the icons simultaneously (i.e. icon theme
 * change, day/night mode, etc.). This can be a pretty expensive
 * operation, as it wipes all the map objects off of the layer and
 * creates them from scratch. Use only if absolutely necessary.
 */
- (void)forceUpdateMapObjects;


/**
 * If enabled, the search layer will obtain and set advertising icons
 * without asking AssetsProvider.
 *
 * @param enable Enable this mode if true, disable otherwise.
 */
- (void)obtainAdIconsWithEnable:(BOOL)enable;


/**
 * Apply insets (in pixels) to the screen. If inset is not zero, search
 * in the cut-off area will not be performed.
 *
 * @param top Top inset.
 * @param left Left inset.
 * @param bottom Bottom inset.
 * @param right Right inset.
 */
- (void)setInsetsWithTop:(NSUInteger)top
                    left:(NSUInteger)left
                  bottom:(NSUInteger)bottom
                   right:(NSUInteger)right;


/**
 * Tells if this object is valid or no. Any method called on an invalid
 * object will throw an exception. The object becomes invalid only on UI
 * thread, and only when its implementation depends on objects already
 * destroyed by now. Please refer to general docs about the interface for
 * details on its invalidation.
 */
@property (nonatomic, readonly, getter=isValid) BOOL valid;

@end

