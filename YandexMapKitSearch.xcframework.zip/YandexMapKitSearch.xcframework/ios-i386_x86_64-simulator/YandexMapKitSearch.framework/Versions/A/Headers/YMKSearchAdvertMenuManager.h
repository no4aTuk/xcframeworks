#import <YandexMapKitSearch/YMKSearchAdvertMenuInfo.h>
#import <YandexMapKitSearch/YMKSearchAdvertMenuListener.h>

#import <YandexRuntime/YRTPlatformBinding.h>

#import <YandexMapKit/YMKPoint.h>

/// @cond EXCLUDE
/**
 * An interface for receiving advertised menu items for the application
 * menu. The application sets the user position and the relevant menu
 * ads are provided. Ads are received in the background, and the
 * application is notified when new menu ads become available.
 */
@interface YMKSearchAdvertMenuManager : YRTPlatformBinding

/**
 * Adds a listener to receive menu ads. The listener will be notified
 * after calls to setPosition.
 *
 * @param menuListener Listener to add.
 */
- (void)addListenerWithMenuListener:(nonnull id<YMKSearchAdvertMenuListener>)menuListener;


/**
 * Removes the listener for menu ads.
 *
 * @param menuListener Listener to remove.
 */
- (void)removeListenerWithMenuListener:(nonnull id<YMKSearchAdvertMenuListener>)menuListener;


/**
 * Sets the current position.
 *
 * @param point New position value.
 */
- (void)setPositionWithPoint:(nonnull YMKPoint *)point;


/**
 * Currently available menu ads.
 *
 * @return collection of menu advertisment items.
 */
@property (nonatomic, readonly, nonnull) YMKSearchAdvertMenuInfo *advertMenuInfo;

@end
/// @endcond

