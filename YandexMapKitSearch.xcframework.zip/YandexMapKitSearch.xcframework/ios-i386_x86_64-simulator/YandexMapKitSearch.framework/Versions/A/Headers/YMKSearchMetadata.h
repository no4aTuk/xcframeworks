#import <YandexMapKitSearch/YMKSearchBanner.h>
#import <YandexMapKitSearch/YMKSearchBusinessResultMetadata.h>
#import <YandexMapKitSearch/YMKSearchDisplayType.h>
#import <YandexMapKitSearch/YMKSearchSort.h>
#import <YandexMapKitSearch/YMKSearchToponymResultMetadata.h>

#import <YandexMapKit/YMKBoundingBox.h>
#import <YandexMapKit/YMKGeoObject.h>

/**
 * Additional info for search response;
 */
@interface YMKSearchMetadata : NSObject

/**
 * Approximate number of found objects.
 */
@property (nonatomic, readonly) NSInteger found;

/**
 * Display type.
 */
@property (nonatomic, readonly) YMKSearchDisplayType displayType;

/**
 * Bounding box of the response as a whole.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKBoundingBox *boundingBox;

/**
 * Server-chosen sorting.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchSort *sort;

/**
 * Geocoder response to the toponym part of the query.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKGeoObject *toponym;

/**
 * Additional info for response from toponym search.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchToponymResultMetadata *toponymResultMetadata;

/**
 * Additional info for response from organization search.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchBusinessResultMetadata *businessResultMetadata;

/**
 * Server-generated request id.
 */
@property (nonatomic, readonly, nonnull) NSString *reqid;

/**
 * Yandex.Direct banners.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchBanner *> *banners;

/**
 * Server-generated request context.
 */
@property (nonatomic, readonly, nonnull) NSString *context;

/**
 * Initial request text.
 */
@property (nonatomic, readonly, nonnull) NSString *requestText;

/**
 * Initial request text with misspell correction.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *correctedRequestText;

/**
 * Initial request bounding box
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKBoundingBox *requestBoundingBox;


+ (nonnull YMKSearchMetadata *)searchMetadataWithFound:( NSInteger)found
                                           displayType:( YMKSearchDisplayType)displayType
                                           boundingBox:(nullable YMKBoundingBox *)boundingBox
                                                  sort:(nullable YMKSearchSort *)sort
                                               toponym:(nullable YMKGeoObject *)toponym
                                 toponymResultMetadata:(nullable YMKSearchToponymResultMetadata *)toponymResultMetadata
                                businessResultMetadata:(nullable YMKSearchBusinessResultMetadata *)businessResultMetadata
                                                 reqid:(nonnull NSString *)reqid
                                               banners:(nonnull NSArray<YMKSearchBanner *> *)banners
                                               context:(nonnull NSString *)context
                                           requestText:(nonnull NSString *)requestText
                                  correctedRequestText:(nullable NSString *)correctedRequestText
                                    requestBoundingBox:(nullable YMKBoundingBox *)requestBoundingBox;


@end

