#import <YandexMapKitSearch/YMKSearchBusinessRating1xObjectMetadata.h>

#import <yandex/maps/mapkit/search/business_rating_1x_object_metadata.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


