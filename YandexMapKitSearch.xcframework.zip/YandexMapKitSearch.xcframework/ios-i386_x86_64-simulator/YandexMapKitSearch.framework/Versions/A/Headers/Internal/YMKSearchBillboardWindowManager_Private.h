#import <YandexMapKitSearch/YMKSearchBillboardWindowManager.h>

#import <YandexRuntime/YRTSubscription.h>

#import <yandex/maps/mapkit/search/billboard_window_manager.h>
#import <yandex/maps/runtime/ios/object.h>

#import <memory>

@interface YMKSearchBillboardWindowManager ()

- (id)initWithWrappedNative:(NSValue *)native;
- (id)initWithNative:(const std::shared_ptr<::yandex::maps::mapkit::search::BillboardWindowManager>&)native;

- (std::shared_ptr<::yandex::maps::mapkit::search::BillboardWindowManager>)nativeBillboardWindowManager;
- (std::shared_ptr<::yandex::maps::mapkit::search::BillboardWindowManager>)native;

@end
