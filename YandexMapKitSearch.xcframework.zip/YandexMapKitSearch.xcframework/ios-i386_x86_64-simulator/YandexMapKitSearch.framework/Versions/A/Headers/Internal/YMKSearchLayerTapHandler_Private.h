#import <YandexMapKitSearch/YMKSearchLayerTapHandler.h>

#import <yandex/maps/mapkit/search/search_layer/search_layer.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>

namespace yandex {
namespace maps {
namespace mapkit {
namespace search {
namespace search_layer {
namespace ios {

class PlacemarkListenerBinding : public ::yandex::maps::mapkit::search::search_layer::PlacemarkListener {
public:
    explicit PlacemarkListenerBinding(
        id<YMKSearchLayerTapHandler> platformListener);

    virtual bool onTap(
        ::yandex::maps::mapkit::search::search_layer::SearchResultItem* searchResultItem) override;

    id<YMKSearchLayerTapHandler> platformReference() const { return platformListener_; }

private:
    __weak id<YMKSearchLayerTapHandler> platformListener_;
};

} // namespace ios
} // namespace search_layer
} // namespace search
} // namespace mapkit
} // namespace maps
} // namespace yandex

namespace yandex {
namespace maps {
namespace runtime {
namespace bindings {
namespace ios {
namespace internal {

template <>
struct ToNative<std::shared_ptr<::yandex::maps::mapkit::search::search_layer::PlacemarkListener>, id<YMKSearchLayerTapHandler>, void> {
    static std::shared_ptr<::yandex::maps::mapkit::search::search_layer::PlacemarkListener> from(
        id<YMKSearchLayerTapHandler> platformPlacemarkListener);
};
template <typename PlatformType>
struct ToNative<std::shared_ptr<::yandex::maps::mapkit::search::search_layer::PlacemarkListener>, PlatformType> {
    static std::shared_ptr<::yandex::maps::mapkit::search::search_layer::PlacemarkListener> from(
        PlatformType platformPlacemarkListener)
    {
        return ToNative<std::shared_ptr<::yandex::maps::mapkit::search::search_layer::PlacemarkListener>, id<YMKSearchLayerTapHandler>>::from(
            platformPlacemarkListener);
    }
};

template <>
struct ToPlatform<std::shared_ptr<::yandex::maps::mapkit::search::search_layer::PlacemarkListener>> {
    static id<YMKSearchLayerTapHandler> from(
        const std::shared_ptr<::yandex::maps::mapkit::search::search_layer::PlacemarkListener>& nativePlacemarkListener);
};

} // namespace internal
} // namespace ios
} // namespace bindings
} // namespace runtime
} // namespace maps
} // namespace yandex
