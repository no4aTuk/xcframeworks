#import <YandexMapKitSearch/YMKSearchWorkingHoursState.h>

#import <yandex/maps/mapkit/search/working_hours.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


