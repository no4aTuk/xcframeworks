#import <YandexMapKitSearch/YMKSearchBillboardRouteManager.h>

#import <YandexRuntime/YRTSubscription.h>

#import <yandex/maps/mapkit/search/billboard_route_manager.h>
#import <yandex/maps/runtime/ios/object.h>

#import <memory>

@interface YMKSearchBillboardRouteManager ()

- (id)initWithWrappedNative:(NSValue *)native;
- (id)initWithNative:(const std::shared_ptr<::yandex::maps::mapkit::search::BillboardRouteManager>&)native;

- (std::shared_ptr<::yandex::maps::mapkit::search::BillboardRouteManager>)nativeBillboardRouteManager;
- (std::shared_ptr<::yandex::maps::mapkit::search::BillboardRouteManager>)native;

@end
