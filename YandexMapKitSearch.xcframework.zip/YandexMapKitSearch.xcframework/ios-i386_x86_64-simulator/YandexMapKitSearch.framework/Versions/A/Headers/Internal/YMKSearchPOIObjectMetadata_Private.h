#import <YandexMapKitSearch/YMKSearchPOIObjectMetadata.h>

#import <yandex/maps/mapkit/search/poi_object_metadata.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


