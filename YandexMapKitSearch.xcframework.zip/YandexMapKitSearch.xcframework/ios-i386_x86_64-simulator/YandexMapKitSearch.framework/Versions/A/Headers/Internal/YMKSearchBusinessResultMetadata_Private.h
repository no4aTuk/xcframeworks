#import <YandexMapKitSearch/YMKSearchBusinessResultMetadata.h>

#import <yandex/maps/mapkit/search/business_result_metadata.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


