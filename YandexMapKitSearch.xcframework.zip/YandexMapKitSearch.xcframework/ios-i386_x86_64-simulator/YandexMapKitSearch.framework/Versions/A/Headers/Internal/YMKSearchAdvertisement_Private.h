#import <YandexMapKitSearch/YMKSearchAdvertisement.h>

#import <yandex/maps/mapkit/search/advertisement.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>



namespace yandex {
namespace maps {
namespace runtime {
namespace bindings {
namespace ios {
namespace internal {

template <>
struct ToNative<::yandex::maps::mapkit::search::Advertisement::Image, YMKSearchAdvertisementImage, void> {
    static ::yandex::maps::mapkit::search::Advertisement::Image from(
        YMKSearchAdvertisementImage* platformImage);
};

template <typename PlatformType>
struct ToNative<::yandex::maps::mapkit::search::Advertisement::Image, PlatformType,
        typename std::enable_if<
            std::is_convertible<PlatformType, YMKSearchAdvertisementImage*>::value>::type> {
    static ::yandex::maps::mapkit::search::Advertisement::Image from(
        PlatformType platformImage)
    {
        return ToNative<::yandex::maps::mapkit::search::Advertisement::Image, YMKSearchAdvertisementImage>::from(
            platformImage);
    }
};

template <>
struct ToPlatform<::yandex::maps::mapkit::search::Advertisement::Image> {
    static YMKSearchAdvertisementImage* from(
        const ::yandex::maps::mapkit::search::Advertisement::Image& image);
};

} // namespace internal
} // namespace ios
} // namespace bindings
} // namespace runtime
} // namespace maps
} // namespace yandex

namespace yandex {
namespace maps {
namespace runtime {
namespace bindings {
namespace ios {
namespace internal {

template <>
struct ToNative<::yandex::maps::mapkit::search::Advertisement::Link, YMKSearchAdvertisementLink, void> {
    static ::yandex::maps::mapkit::search::Advertisement::Link from(
        YMKSearchAdvertisementLink* platformLink);
};

template <typename PlatformType>
struct ToNative<::yandex::maps::mapkit::search::Advertisement::Link, PlatformType,
        typename std::enable_if<
            std::is_convertible<PlatformType, YMKSearchAdvertisementLink*>::value>::type> {
    static ::yandex::maps::mapkit::search::Advertisement::Link from(
        PlatformType platformLink)
    {
        return ToNative<::yandex::maps::mapkit::search::Advertisement::Link, YMKSearchAdvertisementLink>::from(
            platformLink);
    }
};

template <>
struct ToPlatform<::yandex::maps::mapkit::search::Advertisement::Link> {
    static YMKSearchAdvertisementLink* from(
        const ::yandex::maps::mapkit::search::Advertisement::Link& link);
};

} // namespace internal
} // namespace ios
} // namespace bindings
} // namespace runtime
} // namespace maps
} // namespace yandex





namespace yandex {
namespace maps {
namespace runtime {
namespace bindings {
namespace ios {
namespace internal {

template <>
struct ToNative<::yandex::maps::mapkit::search::Advertisement::Product, YMKSearchAdvertisementProduct, void> {
    static ::yandex::maps::mapkit::search::Advertisement::Product from(
        YMKSearchAdvertisementProduct* platformProduct);
};

template <typename PlatformType>
struct ToNative<::yandex::maps::mapkit::search::Advertisement::Product, PlatformType,
        typename std::enable_if<
            std::is_convertible<PlatformType, YMKSearchAdvertisementProduct*>::value>::type> {
    static ::yandex::maps::mapkit::search::Advertisement::Product from(
        PlatformType platformProduct)
    {
        return ToNative<::yandex::maps::mapkit::search::Advertisement::Product, YMKSearchAdvertisementProduct>::from(
            platformProduct);
    }
};

template <>
struct ToPlatform<::yandex::maps::mapkit::search::Advertisement::Product> {
    static YMKSearchAdvertisementProduct* from(
        const ::yandex::maps::mapkit::search::Advertisement::Product& product);
};

} // namespace internal
} // namespace ios
} // namespace bindings
} // namespace runtime
} // namespace maps
} // namespace yandex


