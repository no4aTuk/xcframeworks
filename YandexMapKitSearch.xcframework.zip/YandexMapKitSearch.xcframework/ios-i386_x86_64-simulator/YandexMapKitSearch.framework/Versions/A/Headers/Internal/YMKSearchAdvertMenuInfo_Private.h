#import <YandexMapKitSearch/YMKSearchAdvertMenuInfo.h>

#import <yandex/maps/mapkit/search/advert_menu_manager.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


