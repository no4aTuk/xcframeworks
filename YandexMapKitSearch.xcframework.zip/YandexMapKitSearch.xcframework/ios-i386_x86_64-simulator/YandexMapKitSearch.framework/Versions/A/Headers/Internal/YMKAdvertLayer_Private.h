#import <YandexMapKitSearch/YMKAdvertLayer.h>

#import <YandexRuntime/YRTSubscription.h>

#import <yandex/maps/mapkit/search/advert_layer/advert_layer.h>
#import <yandex/maps/runtime/ios/object.h>

#import <memory>

@interface YMKAdvertLayer ()

- (id)initWithWrappedNative:(NSValue *)native;
- (id)initWithNative:(const std::shared_ptr<::yandex::maps::mapkit::search::advert_layer::AdvertLayer>&)native;

- (std::shared_ptr<::yandex::maps::mapkit::search::advert_layer::AdvertLayer>)nativeAdvertLayer;
- (std::shared_ptr<::yandex::maps::mapkit::search::advert_layer::AdvertLayer>)native;

@end
