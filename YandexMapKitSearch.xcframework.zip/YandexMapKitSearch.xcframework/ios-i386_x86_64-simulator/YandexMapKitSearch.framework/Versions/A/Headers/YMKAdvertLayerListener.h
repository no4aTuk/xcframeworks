#import <YandexMapKit/YMKGeoObject.h>

/// @cond EXCLUDE
@protocol YMKAdvertLayerListener <NSObject>

/**
 * Method to receive show events.
 */
- (void)onAdvertPinShownWithGeoObject:(nonnull YMKGeoObject *)geoObject;


/**
 * Method to receive hide events.
 */
- (void)onAdvertPinHiddenWithGeoObject:(nonnull YMKGeoObject *)geoObject;


/**
 * Method to receive tap events.
 */
- (void)onAdvertPinTappedWithGeoObject:(nonnull YMKGeoObject *)geoObject;


/**
 * Method to receive impression events.
 */
- (void)onAdvertPinImpressionCountedWithGeoObject:(nonnull YMKGeoObject *)geoObject
                                     dailyCounter:(NSInteger)dailyCounter
                                     totalCounter:(NSInteger)totalCounter;


@end
/// @endcond
