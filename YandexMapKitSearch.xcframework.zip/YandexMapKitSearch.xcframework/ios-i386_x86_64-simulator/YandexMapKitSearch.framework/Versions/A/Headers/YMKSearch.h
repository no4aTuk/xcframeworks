#import <YandexMapKitSearch/YMKAdvertLayer.h>
#import <YandexMapKitSearch/YMKAdvertLayerAssetProvider.h>
#import <YandexMapKitSearch/YMKSearchBitmapDownloader.h>
#import <YandexMapKitSearch/YMKSearchLayer.h>
#import <YandexMapKitSearch/YMKSearchSearchManager.h>

#import <YandexRuntime/YRTPlatformBinding.h>

#import <YandexMapKit/YMKMapWindow.h>

@class YMKSearchAdvertMenuManager;
@class YMKSearchBillboardRouteManager;
@class YMKSearchBillboardWindowManager;
@class YMKSearchManager;

@interface YMKSearch : YRTPlatformBinding

/**
 * Gets the search_layer object.
 */
- (nonnull YMKSearchLayer *)createSearchLayerWithMapWindow:(nonnull YMKMapWindow *)mapWindow;


/**
 * Gets the advert_layer object.
 */
- (nonnull YMKAdvertLayer *)createAdvertLayerWithAdvertPageId:(nonnull NSString *)advertPageId
                                                    mapWindow:(nonnull YMKMapWindow *)mapWindow
                                                assetProvider:(nonnull id<YMKAdvertLayerAssetProvider>)assetProvider;


/**
 * Creates a manager that allows to search for various geographical
 * objects using a variety of parameters.
 */
- (nonnull YMKSearchManager *)createSearchManagerWithSearchManagerType:(YMKSearchSearchManagerType)searchManagerType;


/// @cond EXCLUDE
/**
 * Creates a manager that allows to get ads in the search menu for
 * places that match the query.
 */
- (nonnull YMKSearchAdvertMenuManager *)createAdvertMenuManagerWithAdvertPageId:(nonnull NSString *)advertPageId;
/// @endcond


/// @cond EXCLUDE
/**
 * Creates a route advert manager that allows to get ads for places of
 * interest and billboards along the route.
 */
- (nonnull YMKSearchBillboardRouteManager *)createBillboardRouteManagerWithAdvertPageId:(nonnull NSString *)advertPageId;
/// @endcond


/// @cond EXCLUDE
/**
 * Creates a billboard manager that allows to get billboards inside the
 * search window.
 */
- (nonnull YMKSearchBillboardWindowManager *)createBillboardWindowManagerWithAdvertPageId:(nonnull NSString *)advertPageId;
/// @endcond


/// @cond EXCLUDE
/**
 * Creates a manager for getting ad icons.
 *
 * @param bitmapCaching Enables or disables internal caching of
 * downloaded bitmaps to disk.
 */
- (nonnull YMKSearchBitmapDownloader *)createBitmapDownloaderWithBitmapCaching:(YMKSearchBitmapCaching)bitmapCaching;
/// @endcond


/**
 * Tells if this object is valid or no. Any method called on an invalid
 * object will throw an exception. The object becomes invalid only on UI
 * thread, and only when its implementation depends on objects already
 * destroyed by now. Please refer to general docs about the interface for
 * details on its invalidation.
 */
@property (nonatomic, readonly, getter=isValid) BOOL valid;

@end

