#import <Foundation/Foundation.h>

/**
 * The type of reference.
 */
@interface YMKSearchReferenceType : NSObject

/**
 * Reference ID.
 */
@property (nonatomic, readonly, nonnull) NSString *id;

/**
 * Reference scope.
 */
@property (nonatomic, readonly, nonnull) NSString *scope;


+ (nonnull YMKSearchReferenceType *)referenceTypeWithId:(nonnull NSString *)id
                                                  scope:(nonnull NSString *)scope;


@end

