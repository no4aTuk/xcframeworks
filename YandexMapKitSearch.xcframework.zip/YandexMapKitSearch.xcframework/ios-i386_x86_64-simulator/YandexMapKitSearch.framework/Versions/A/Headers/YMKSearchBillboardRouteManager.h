#import <YandexMapKitSearch/YMKSearchAdvertRouteListener.h>

#import <YandexRuntime/YRTPlatformBinding.h>

#import <YandexMapKit/YMKGeoObject.h>
#import <YandexMapKit/YMKPolyline.h>
#import <YandexMapKit/YMKPolylinePosition.h>

/// @cond EXCLUDE
/**
 * Allows to get an advertisment to show along the user route.
 *
 * Advertisement is selected based on the route provided (this allows
 * hiding irrelevant ads) and the provided route position (this allows
 * hiding ads which have already been passed).
 *
 * The new ad is received in the background, notifiying the user when a
 * new advertisement is available.
 */
@interface YMKSearchBillboardRouteManager : YRTPlatformBinding

/**
 * Sets the listener to receive route ads. The listener may be notified
 * after calls to `setRoute` and `setRoutePosition`.
 *
 * @param routeListener Listener to add.
 */
- (void)addListenerWithRouteListener:(nonnull id<YMKSearchAdvertRouteListener>)routeListener;


/**
 * Removes the listener for route ads.
 *
 * @param routeListener Listener to remove.
 */
- (void)removeListenerWithRouteListener:(nonnull id<YMKSearchAdvertRouteListener>)routeListener;


/**
 * Sets the route geometry to receive route ads.
 *
 * @param route Route geometry. May not be null; use `resetRoute` to
 * reset.
 */
- (void)setRouteWithRoute:(nonnull YMKPolyline *)route;


/**
 * Resets the route geometry. No further notifications will be issued to
 * listeners until a new route is provided.
 */
- (void)resetRoute;


/**
 * Sets the current position on the route to receive the route ad if
 * possible. Throws if no route set.
 *
 * @param point New route position value.
 */
- (void)setRoutePositionWithPoint:(nonnull YMKPolylinePosition *)point;


/**
 * Current route ads.
 *
 * @return collection of advertised `GeoObjects`.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKGeoObject *> *advertObjects;

@end
/// @endcond

