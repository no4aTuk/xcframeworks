#import <Foundation/Foundation.h>

/// @cond EXCLUDE
/**
 * Listener to be notified when new billboards are received.
 */
@protocol YMKSearchBillboardListener <NSObject>

/**
 * Method to be called on the listener to notify of a new ad.
 */
- (void)onBillboardReceived;


@end
/// @endcond
