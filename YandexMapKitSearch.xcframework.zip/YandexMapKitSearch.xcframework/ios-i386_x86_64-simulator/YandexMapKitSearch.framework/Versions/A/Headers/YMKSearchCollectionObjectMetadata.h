#import <YandexMapKitSearch/YMKSearchKeyValuePair.h>

/**
 * Contains information about a collection.
 */
@interface YMKSearchCollectionObjectMetadata : NSObject

/**
 * Machine readable collection identifier.
 */
@property (nonatomic, readonly, nonnull) NSString *id;

/**
 * Collection photo URL.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *photoUrlTemplate;

/**
 * Some additional collection properties. For example, [ {"key":
 * "short_title", "value": "Лучшие места для ужина"},
 * {"key": "subtitle", "value": "15 мест"}, ].
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchKeyValuePair *> *properties;


+ (nonnull YMKSearchCollectionObjectMetadata *)collectionObjectMetadataWithId:(nonnull NSString *)id
                                                             photoUrlTemplate:(nullable NSString *)photoUrlTemplate
                                                                   properties:(nonnull NSArray<YMKSearchKeyValuePair *> *)properties;


@end

