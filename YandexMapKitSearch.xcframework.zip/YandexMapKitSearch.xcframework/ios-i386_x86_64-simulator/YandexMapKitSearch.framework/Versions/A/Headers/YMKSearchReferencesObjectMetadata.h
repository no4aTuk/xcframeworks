#import <YandexMapKitSearch/YMKSearchReferenceType.h>

/**
 * Reference metadata information.
 */
@interface YMKSearchReferencesObjectMetadata : NSObject

/**
 * The  list of references.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchReferenceType *> *references;


+ (nonnull YMKSearchReferencesObjectMetadata *)referencesObjectMetadataWithReferences:(nonnull NSArray<YMKSearchReferenceType *> *)references;


@end

