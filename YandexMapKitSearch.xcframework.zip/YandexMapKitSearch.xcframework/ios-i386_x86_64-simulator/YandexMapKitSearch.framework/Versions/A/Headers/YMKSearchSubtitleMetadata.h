#import <YandexMapKitSearch/YMKSearchSubtitleItem.h>

/**
 * Subtitle snippet.
 */
@interface YMKSearchSubtitleMetadata : NSObject

/**
 * List of subtitles.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchSubtitleItem *> *subtitleItems;


+ (nonnull YMKSearchSubtitleMetadata *)subtitleMetadataWithSubtitleItems:(nonnull NSArray<YMKSearchSubtitleItem *> *)subtitleItems;


@end

