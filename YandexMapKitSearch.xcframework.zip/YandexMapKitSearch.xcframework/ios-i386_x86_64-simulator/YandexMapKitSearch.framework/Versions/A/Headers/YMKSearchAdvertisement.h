#import <YandexMapKitSearch/YMKSearchKeyValuePair.h>

#import <YandexMapKit/YMKTaxiMoney.h>

@class YMKSearchAdvertisementImage;
@class YMKSearchAdvertisementLink;
@class YMKSearchAdvertisementProduct;
@class YMKSearchAdvertisementPromo;
@class YMKSearchAdvertisementTaggedImage;
@class YMKSearchAdvertisementTextData;

@interface YMKSearchAdvertisement : NSObject

/**
 * Text advert.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchAdvertisementTextData *textData;

/**
 * Promo.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchAdvertisementPromo *promo;

/**
 * Products.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchAdvertisementProduct *> *products;

/**
 * Company detailed description.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *about;

/**
 * Company logo.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchAdvertisementImage *logo;

/**
 * Photo.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchAdvertisementImage *photo;

/**
 * Additional typed images.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchAdvertisementTaggedImage *> *taggedImages;

/**
 * Human-readable identifier for logging.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *logId;

/**
 * Additional advertisement properties.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchKeyValuePair *> *properties;


+ (nonnull YMKSearchAdvertisement *)advertisementWithTextData:(nullable YMKSearchAdvertisementTextData *)textData
                                                        promo:(nullable YMKSearchAdvertisementPromo *)promo
                                                     products:(nonnull NSArray<YMKSearchAdvertisementProduct *> *)products
                                                        about:(nullable NSString *)about
                                                         logo:(nullable YMKSearchAdvertisementImage *)logo
                                                        photo:(nullable YMKSearchAdvertisementImage *)photo
                                                 taggedImages:(nonnull NSArray<YMKSearchAdvertisementTaggedImage *> *)taggedImages
                                                        logId:(nullable NSString *)logId
                                                   properties:(nonnull NSArray<YMKSearchKeyValuePair *> *)properties;


@end


/**
 * Image.
 */
@interface YMKSearchAdvertisementImage : NSObject

/**
 * urlTemplate for the image. Available sizes are listed here:
 * http://api.yandex.ru/fotki/doc/format-ref/f-img.xml
 */
@property (nonatomic, readonly, nonnull) NSString *urlTemplate;


+ (nonnull YMKSearchAdvertisementImage *)imageWithUrlTemplate:(nonnull NSString *)urlTemplate;


@end


/**
 * Link.
 */
@interface YMKSearchAdvertisementLink : NSObject

/**
 * Optional link type.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *type;

/**
 * Link URI.
 */
@property (nonatomic, readonly, nonnull) NSString *uri;


+ (nonnull YMKSearchAdvertisementLink *)linkWithType:(nullable NSString *)type
                                                 uri:(nonnull NSString *)uri;


@end


/**
 * Tagged Image.
 */
@interface YMKSearchAdvertisementTaggedImage : NSObject

/**
 * Image itself.
 */
@property (nonatomic, readonly, nonnull) YMKSearchAdvertisementImage *image;

/**
 * Additional string-based info.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *tags;

/**
 * Additional links for the image.
 */
@property (nonatomic, readonly, nonnull) NSArray<YMKSearchAdvertisementLink *> *links;


+ (nonnull YMKSearchAdvertisementTaggedImage *)taggedImageWithImage:(nonnull YMKSearchAdvertisementImage *)image
                                                               tags:(nonnull NSArray<NSString *> *)tags
                                                              links:(nonnull NSArray<YMKSearchAdvertisementLink *> *)links;


@end


/**
 * Promo.
 */
@interface YMKSearchAdvertisementPromo : NSObject

/**
 * Title.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *title;

/**
 * Details.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *details;

/**
 * Disclaimers.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *disclaimers;

/**
 * URL.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *url;

/**
 * Banner.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchAdvertisementImage *banner;


+ (nonnull YMKSearchAdvertisementPromo *)promoWithTitle:(nullable NSString *)title
                                                details:(nullable NSString *)details
                                            disclaimers:(nonnull NSArray<NSString *> *)disclaimers
                                                    url:(nullable NSString *)url
                                                 banner:(nullable YMKSearchAdvertisementImage *)banner;


@end


/**
 * Product.
 */
@interface YMKSearchAdvertisementProduct : NSObject

/**
 * Title.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *title;

/**
 * URL.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *url;

/**
 * Photo.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKSearchAdvertisementImage *photo;

/**
 * Price.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) YMKTaxiMoney *price;


+ (nonnull YMKSearchAdvertisementProduct *)productWithTitle:(nullable NSString *)title
                                                        url:(nullable NSString *)url
                                                      photo:(nullable YMKSearchAdvertisementImage *)photo
                                                      price:(nullable YMKTaxiMoney *)price;


@end


/**
 * Text.
 */
@interface YMKSearchAdvertisementTextData : NSObject

/**
 * Title.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *title;

/**
 * Text.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *text;

/**
 * Disclaimers.
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *disclaimers;

/**
 * Optional link.
 *
 * Optional property, can be null.
 */
@property (nonatomic, readonly, nullable) NSString *url;


+ (nonnull YMKSearchAdvertisementTextData *)textDataWithTitle:(nullable NSString *)title
                                                         text:(nullable NSString *)text
                                                  disclaimers:(nonnull NSArray<NSString *> *)disclaimers
                                                          url:(nullable NSString *)url;


@end

