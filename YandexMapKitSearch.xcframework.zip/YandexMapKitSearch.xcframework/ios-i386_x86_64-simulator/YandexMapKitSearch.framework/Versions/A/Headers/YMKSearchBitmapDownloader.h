#import <YandexMapKitSearch/YMKBitmapSession.h>

#import <YandexRuntime/YRTPlatformBinding.h>

/// @cond EXCLUDE
/**
 * Enum to control caching of downloaded bitmaps.
 */
typedef NS_ENUM(NSUInteger, YMKSearchBitmapCaching) {

    YMKSearchBitmapCachingEnabled,

    YMKSearchBitmapCachingDisabled
};
/// @endcond


/// @cond EXCLUDE
/**
 * Allows to download advert bitmap images.
 */
@interface YMKSearchBitmapDownloader : YRTPlatformBinding

/**
 * Requests an image to display.
 *
 * @param id Image identifier.
 * @param scale Scale of resulting image.
 * @param bitmapListener Receive resulting image using this listener.
 *
 * @return Session handle that should be stored until image is received.
 */
- (nonnull YMKBitmapSession *)requestBitmapWithId:(nonnull NSString *)id
                                            scale:(float)scale
                                   bitmapListener:(nonnull YMKBitmapSessionBitmapListener)bitmapListener;


@end
/// @endcond

