#import <YandexMapKit/YMKUriObjectMetadata.h>

#import <yandex/maps/mapkit/uri/uri_object_metadata.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


