#import <YandexMapKit/YMKPersonalizedPoiTapInfo.h>

#import <yandex/maps/mapkit/personalized_poi/personalized_poi_tap_info.h>
#import <yandex/maps/runtime/bindings/ios/to_native.h>
#import <yandex/maps/runtime/bindings/ios/to_platform.h>


