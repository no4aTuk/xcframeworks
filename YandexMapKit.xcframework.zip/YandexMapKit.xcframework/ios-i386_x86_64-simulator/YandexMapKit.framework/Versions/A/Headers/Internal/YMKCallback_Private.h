#import <YandexMapKit/YMKCallback.h>

#import <yandex/maps/mapkit/map/callback.h>

namespace yandex {
namespace maps {
namespace mapkit {
namespace map {
namespace ios {

OnTaskFinished onTaskFinished(
    YMKCallback handler);

} // namespace ios
} // namespace map
} // namespace mapkit
} // namespace maps
} // namespace yandex
