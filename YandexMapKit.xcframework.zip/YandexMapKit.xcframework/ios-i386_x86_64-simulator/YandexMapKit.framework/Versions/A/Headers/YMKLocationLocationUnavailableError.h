#import <YandexRuntime/YRTError.h>

/**
 * This error is returned if the location is not available.
 */
@interface YMKLocationLocationUnavailableError : YRTError

@end

